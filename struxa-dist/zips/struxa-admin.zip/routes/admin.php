<?php

declare(strict_types=1);

use App\Plugin\StruxaCatalogAdminRouteRegistrar;
use Slim\App;

/**
 * Catalog admin URLs are registered via {@see StruxaCatalogAdminRouteRegistrar} (core CMS)
 * using Slim's standard ->add() middleware. Kept for plugin package layout / older CMS versions.
 */
return static function (App $app, \App\Plugin\PluginBootContext $ctx): void {
    StruxaCatalogAdminRouteRegistrar::register($app, $ctx);
};
