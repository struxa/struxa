<?php

declare(strict_types=1);

use App\Access\PermissionSlug;
use App\Flash;
use App\Http\Middleware\RequireCmsStaff;
use App\Http\Middleware\RequirePermission;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\App;
use Slim\Exception\HttpNotFoundException;
use Slim\Routing\RouteContext;
use StruxaAdmin\CatalogPublisher;
use StruxaAdmin\CatalogSettings;
use StruxaAdmin\CatalogSubmissionRepository;
use StruxaAdmin\CatalogSubmissionValidator;
use StruxaAdmin\GitHubRepoClient;
use StruxaAdmin\SubmissionStatus;

return static function (App $app, \App\Plugin\PluginBootContext $ctx): void {
    $twig = $ctx->twig();
    $pdo = $ctx->pdo();
    $auth = $ctx->auth();
    $root = $ctx->projectRoot();
    $ns = '@plugin_struxa_admin';

    $settings = new CatalogSettings($pdo, $root);
    $submissions = new CatalogSubmissionRepository($pdo);
    $github = new GitHubRepoClient($settings->githubToken());
    $publisher = new CatalogPublisher($settings, $submissions, $github);

    $middleware = new RequireCmsStaff($auth, $pdo);
    $perm = new RequirePermission($pdo, [PermissionSlug::MANAGE_PLUGINS]);

    $adminView = static function (Request $request, array $extra = []) use ($ctx): array {
        /** @var array<string, mixed> $cmsUser */
        $cmsUser = $request->getAttribute('cms_user') ?? [];

        return array_merge($ctx->viewData([
            'admin_nav' => 'extensions_plugins',
            'cms_user' => $cmsUser,
        ]), $extra);
    };

    $cmsUid = static function (Request $request): ?int {
        /** @var array<string, mixed> $u */
        $u = $request->getAttribute('cms_user') ?? [];
        $id = isset($u['id']) ? (int) $u['id'] : 0;

        return $id > 0 ? $id : null;
    };

    $app->group('/admin', function (\Slim\Routing\RouteCollectorProxy $group) use (
        $twig,
        $adminView,
        $submissions,
        $publisher,
        $settings,
        $cmsUid,
        $ns
    ): void {
        $group->get('/extensions/struxa-catalog/submissions', function (Request $request, Response $response) use (
            $twig,
            $adminView,
            $submissions,
            $settings,
            $ns
        ): Response {
            $q = $request->getQueryParams();
            $status = isset($q['status']) ? trim((string) $q['status']) : SubmissionStatus::PENDING;
            $kind = isset($q['kind']) ? trim((string) $q['kind']) : '';

            return $twig->render($response, $ns . '/admin/submissions.twig', $adminView($request, [
                'submission_rows' => $submissions->listByStatus(
                    $status !== '' ? $status : null,
                    $kind !== '' ? $kind : null,
                    100
                ),
                'filter_status' => $status,
                'filter_kind' => $kind,
                'pending_count' => $submissions->countPending(),
                'dist_root' => $settings->distRoot(),
            ]));
        })->setName('admin.struxa_catalog.submissions');

        $group->get('/extensions/struxa-catalog/submissions/{id:[0-9]+}', function (
            Request $request,
            Response $response,
            array $args
        ) use ($twig, $adminView, $submissions, $settings, $ns): Response {
            $id = (int) $args['id'];
            $row = $submissions->findById($id);
            if ($row === null) {
                throw new HttpNotFoundException($request);
            }

            return $twig->render($response, $ns . '/admin/submission_show.twig', $adminView($request, [
                'submission' => $row,
                'dist_root' => $settings->distRoot(),
            ]));
        })->setName('admin.struxa_catalog.submission_show');

        $group->post('/extensions/struxa-catalog/submissions/{id:[0-9]+}/review', function (
            Request $request,
            Response $response,
            array $args
        ) use ($submissions, $publisher, $cmsUid): Response {
            $id = (int) $args['id'];
            $row = $submissions->findById($id);
            $parser = RouteContext::fromRequest($request)->getRouteParser();
            $back = $parser->urlFor('admin.struxa_catalog.submission_show', ['id' => (string) $id]);
            if ($row === null) {
                throw new HttpNotFoundException($request);
            }
            $body = $request->getParsedBody();
            $body = is_array($body) ? $body : [];
            $action = trim((string) ($body['action'] ?? ''));
            $notes = trim((string) ($body['reviewer_notes'] ?? ''));

            if ($action === 'approve') {
                $pub = $publisher->approveAndPublish($row);
                if (!$pub['ok']) {
                    Flash::set('error', 'Approval failed: ' . $pub['error']);

                    return $response->withHeader('Location', $back)->withStatus(302);
                }
                $submissions->setStatus($id, SubmissionStatus::APPROVED, $notes, $cmsUid($request), gmdate('Y-m-d H:i:s'));
                Flash::set('success', 'Approved and published to the distribution catalog (repo.json + ZIP).');
            } elseif ($action === 'reject') {
                $submissions->setStatus($id, SubmissionStatus::REJECTED, $notes, $cmsUid($request));
                Flash::set('success', 'Submission rejected.');
            } else {
                Flash::set('error', 'Unknown action.');
            }

            return $response->withHeader('Location', $back)->withStatus(302);
        })->setName('admin.struxa_catalog.submission_review');

        $group->get('/extensions/struxa-catalog/settings', function (Request $request, Response $response) use (
            $twig,
            $adminView,
            $settings,
            $ns
        ): Response {
            return $twig->render($response, $ns . '/admin/settings.twig', $adminView($request, [
                'dist_root' => $settings->distRoot(),
                'zip_base_url' => $settings->zipBaseUrl(),
                'screenshot_base_url' => $settings->screenshotPublicBaseUrl(),
                'has_github_token' => $settings->githubToken() !== null,
            ]));
        })->setName('admin.struxa_catalog.settings');

        $group->post('/extensions/struxa-catalog/settings', function (Request $request, Response $response) use (
            $settings,
            $publisher
        ): Response {
            $parser = RouteContext::fromRequest($request)->getRouteParser();
            $back = $parser->urlFor('admin.struxa_catalog.settings');
            $body = $request->getParsedBody();
            $body = is_array($body) ? $body : [];
            $action = trim((string) ($body['action'] ?? 'save'));

            if ($action === 'regenerate') {
                $regen = $publisher->regenerateCatalog();
                Flash::set($regen['ok'] ? 'success' : 'error', $regen['ok'] ? 'Catalog repo.json regenerated.' : $regen['error']);

                return $response->withHeader('Location', $back)->withStatus(302);
            }

            $settings->save([
                CatalogSettings::KEY_DIST_ROOT => trim((string) ($body['dist_root'] ?? '')),
                CatalogSettings::KEY_ZIP_BASE_URL => trim((string) ($body['zip_base_url'] ?? '')),
                CatalogSettings::KEY_SCREENSHOT_BASE_URL => trim((string) ($body['screenshot_base_url'] ?? '')),
                CatalogSettings::KEY_GITHUB_TOKEN => trim((string) ($body['github_token'] ?? '')),
            ]);
            Flash::set('success', 'Catalog settings saved.');

            return $response->withHeader('Location', $back)->withStatus(302);
        })->setName('admin.struxa_catalog.settings.save');
    })->add($perm)->add($middleware);
};
