-- Idempotent: icon_image is in 001_forum_schema.sql for fresh installs; this migration
-- only adds the column on sites that ran an older 001 without it.

SET @db := DATABASE();

SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE forum_forums ADD COLUMN icon_image VARCHAR(500) NULL DEFAULT NULL AFTER icon',
    'DO 0'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'forum_forums' AND COLUMN_NAME = 'icon_image'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
